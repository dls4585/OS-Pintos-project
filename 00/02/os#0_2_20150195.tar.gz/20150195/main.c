#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "list.h"
#include "hash.h"
#include "bitmap.h"
#define MAX_STRING 50
typedef struct bitmapS{
	struct bitmap* p;
}bitmapS;
bitmapS bitmaps[10];
int main(int argc, char* argv[]) {
	if (argc < 1) {
		exit(-1);
	}
	char input[MAX_STRING] = { 0 };
	char** s = (char**)malloc(sizeof(char*) * 7);
	int i;
	for (i = 0; i < 7; i++) {
		s[i] = (char*)malloc(sizeof(char) * MAX_STRING);
	}
	struct list lists[10];
	struct hash hashs[10];
	
	list_less_func* less_l = list_less_func2;
	hash_hash_func* hashf = hash_hash_func2;
	hash_less_func* less_h = hash_less_func2;
	while (1) {
		scanf("%[^\n]s", input);
		if (strncmp(input, "quit", sizeof("quit")) == 0) {
			break;
		}
		char c = getchar();
		int i = 0;
		char* ptr = strtok(input, " ");
		strcpy(s[i++], ptr);
		int cnt = 1;
		while (1) {
			ptr = strtok(NULL, " ");
			if (ptr == NULL) break;
			cnt++;
			strcpy(s[i++], ptr);
		}
		if (strncmp(s[0], "create", sizeof("create")) == 0) { //create ~~
			if (strncmp(s[1], "list", sizeof("list")) == 0) {
				size_t idx = atoi(&s[2][4]);
				list_init(&lists[idx]);
			}
			else if (strncmp(s[1], "hashtable", sizeof("hashtable")) == 0) {
				size_t idx = atoi(&s[2][4]);
				hash_init(&hashs[idx], hashf, less_h, NULL);
			}
			else if (strncmp(s[1], "bitmap", sizeof("bitmap")) == 0) {
				size_t idx = atoi(&s[2][2]);
				size_t bit_cnt = atoi(s[3]);
				bitmaps[idx].p = bitmap_create(bit_cnt);
			}
		}
		else if (strncmp(s[0], "list_push_back", sizeof("list_push_back")) == 0) {
			size_t idx = atoi(&s[1][4]);
			struct list_item* item = (struct list_item*)malloc(sizeof(struct list_item));
			item->data = atoi(s[2]);
			struct list_elem elem;
			elem.prev = NULL; elem.next=NULL;
			item->elem = elem;
			list_push_back(&lists[idx], &(item->elem));
		}
		else if (strncmp(s[0], "list_push_front", sizeof("list_push_front")) == 0) {
			size_t idx = atoi(&s[1][4]);
			struct list_item* item = (struct list_item*)malloc(sizeof(struct list_item));
			item->data = atoi(s[2]);
			list_push_front(&lists[idx], &(item->elem));
		}
		else if (strncmp(s[0], "list_pop_back", sizeof("list_pop_back")) == 0) {
			size_t idx = atoi(&s[1][4]);
			list_pop_back(&lists[idx]);
		}
		else if (strncmp(s[0], "list_pop_front", sizeof("list_pop_front")) == 0) {
			size_t idx = atoi(&s[1][4]);
			list_pop_front(&lists[idx]);
		}
		else if (strncmp(s[0], "list_front", sizeof("list_front")) == 0) {
			size_t idx = atoi(&s[1][4]);
			struct list_item* item = list_entry(list_front(&lists[idx]), struct list_item, elem);
			printf("%d\n", item->data);
		}
		else if (strncmp(s[0], "list_back", sizeof("list_back")) == 0) {
			size_t idx = atoi(&s[1][4]);
			struct list_item* item = list_entry(list_back(&lists[idx]), struct list_item, elem);
			printf("%d\n", item->data);
		}
		else if (strncmp(s[0], "list_insert_ordered", sizeof("list_insert_ordered")) == 0) {
            size_t idx = atoi(&s[1][4]);
            struct list_item* item = (struct list_item*)malloc(sizeof(struct list_item));
            item->data = atoi(s[2]);
            list_sort(&lists[idx], less_l, NULL);
            list_insert_ordered(&lists[idx], &(item->elem), less_l, NULL);
        }
		else if (strncmp(s[0], "list_insert", sizeof("list_back")) == 0) {
			size_t idx = atoi(&s[1][4]);
			size_t before = atoi(s[2]);
			struct list_item* item = (struct list_item*)malloc(sizeof(struct list_item));
			item->data = atoi(s[3]);
			if (before == 0) {
				list_push_front(&lists[idx], &(item->elem));
			}
			else if (before >= list_size(&lists[idx])) {
				list_push_back(&lists[idx], &(item->elem));
			}
			else {
				list_insert(list_search(&lists[idx], before), &(item->elem));
			}
		}
		else if (strncmp(s[0], "list_empty", sizeof("list_empty")) == 0) {
			size_t idx = atoi(&s[1][4]);
			if (list_empty(&lists[idx])) {
				printf("true\n");
			}
			else {
				printf("false\n");
			}
		}
		else if (strncmp(s[0], "list_size", sizeof("list_size")) == 0) {
			size_t idx = atoi(&s[1][4]);
			printf("%zu\n", list_size(&lists[idx]));
		}
		else if (strncmp(s[0], "list_max", sizeof("list_max")) == 0) {
			size_t idx = atoi(&s[1][4]);
			struct list_item* item = list_entry(list_max(&lists[idx], less_l, NULL), struct list_item, elem);
			printf("%d\n", item->data);
		}
		else if (strncmp(s[0], "list_min", sizeof("list_min")) == 0) {
			size_t idx = atoi(&s[1][4]);
			struct list_item* item = list_entry(list_min(&lists[idx], less_l, NULL), struct list_item, elem);
			printf("%d\n", item->data);
		}
		else if (strncmp(s[0], "list_remove", sizeof("list_remove")) == 0) {
			size_t idx = atoi(&s[1][4]);
			size_t elem_idx = atoi(s[2]);
			list_remove(list_search(&lists[idx], elem_idx));
		}
		else if (strncmp(s[0], "list_reverse", sizeof("list_reverse")) == 0) {
			size_t idx = atoi(&s[1][4]);
			list_reverse(&lists[idx]);
		}
		else if (strncmp(s[0], "list_shuffle", sizeof("list_shuffle")) == 0) {
			size_t idx = atoi(&s[1][4]);
			list_shuffle(&lists[idx]);
		}
		else if (strncmp(s[0], "list_sort", sizeof("list_sort")) == 0) {
			size_t idx = atoi(&s[1][4]);
			list_sort(&lists[idx], less_l, NULL);
		}
		else if (strncmp(s[0], "list_splice", sizeof("list_splice")) == 0) {
			size_t to = atoi(&s[1][4]);
			size_t from = atoi(&s[3][4]);
			size_t before = atoi(s[2]);
			size_t first = atoi(s[4]);
			size_t last = atoi(s[5]); // exclusive
			list_splice(list_search(&lists[to], before), list_search(&lists[from], first), list_search(&lists[from], last));
		}
		else if (strncmp(s[0], "list_swap", sizeof("list_swap")) == 0) {
			size_t idx = atoi(&s[1][4]);
			size_t a = atoi(s[2]);
			size_t b = atoi(s[3]);
			if(a>b){
				size_t temp=a;
				a = b;
				b = temp;
			}
			struct list_elem* A = list_search(&lists[idx], a);
			struct list_elem* B = list_search(&lists[idx], b);
			list_swap(&lists[idx], A, B);
		} 
		else if (strncmp(s[0], "list_unique", sizeof("list_unique")) == 0) {
			if (strncmp(s[2], "list", sizeof("list")-1)!=0) {
				size_t idx = atoi(&s[1][4]);
				list_unique(&lists[idx], NULL, less_l, NULL);
			}
			else {
				size_t idx = atoi(&s[1][4]);
				size_t dup = atoi(&s[2][4]);
				list_unique(&lists[idx], &lists[dup], less_l, NULL);
			}
		}
		else if (strncmp(s[0], "hash_insert", sizeof("hash_insert")) == 0) {
			size_t idx = atoi(&s[1][4]);
			struct hash_item* item = (struct hash_item*)malloc(sizeof(struct hash_item));
			item->data = atoi(s[2]);
			hash_insert(&hashs[idx], &(item->elem));
		}
		else if (strncmp(s[0], "hash_apply", sizeof("hash_apply")) == 0) {
			size_t idx = atoi(&s[1][4]);

			if (strncmp(s[2], "square", sizeof("square")) == 0) {
				hash_action_func* act = hash_square;
				hash_apply(&hashs[idx], act);
			}
			else if (strncmp(s[2], "triple", sizeof("triple")) == 0) {
				hash_action_func* act = hash_triple;
				hash_apply(&hashs[idx], act);
			}
		}
		else if (strncmp(s[0], "hash_delete", sizeof("hash_delete")) == 0) {
			size_t idx = atoi(&s[1][4]);
			struct hash_item* item = (struct hash_item*)malloc(sizeof(struct hash_item));
			item->data = atoi(s[2]);
			hash_delete(&hashs[idx], &(item->elem));
		}
		else if (strncmp(s[0], "hash_empty", sizeof("hash_empty")) == 0) {
			size_t idx = atoi(&s[1][4]);
			if (hash_empty(&hashs[idx])) {
				printf("true\n");
			}
			else {
				printf("false\n");
			}
		}
		else if (strncmp(s[0], "hash_size", sizeof("hash_size")) == 0) {
			size_t idx = atoi(&s[1][4]);
			size_t size = hash_size(&hashs[idx]);
			printf("%zu\n", size);
		}
		else if (strncmp(s[0], "hash_clear", sizeof("hash_clear")) == 0) {
			size_t idx = atoi(&s[1][4]);
			hash_clear(&hashs[idx], NULL);
		}
		else if (strncmp(s[0], "hash_find", sizeof("hash_find")) == 0) {
			size_t idx = atoi(&s[1][4]);
			struct hash_item* item = (struct hash_item*)malloc(sizeof(struct hash_item));
			item->data = atoi(s[2]);
			struct hash_elem* elem = hash_find(&hashs[idx], &(item->elem));
			if (elem!=NULL){	
				item = hash_entry(elem, struct hash_item, elem);
				printf("%d\n", item->data);
			}
		}
		else if (strncmp(s[0], "hash_replace", sizeof("hash_replace")) == 0) {
			size_t idx = atoi(&s[1][4]);
			struct hash_item* item = (struct hash_item*)malloc(sizeof(struct hash_item));
			item->data = atoi(s[2]);
			hash_replace(&hashs[idx], &(item->elem));
		}
		else if (strncmp(s[0], "bitmap_mark", sizeof("bitmap_mark")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t bit_idx = atoi(s[2]);
			bitmap_mark(bitmaps[idx].p, bit_idx);
		}
		else if (strncmp(s[0], "bitmap_all", sizeof("bitmap_all")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t start = atoi(s[2]);
			size_t cnt = atoi(s[3]);
			printf("%s\n", bitmap_all(bitmaps[idx].p, start, cnt) ? "true" : "false");
		}
		else if (strncmp(s[0], "bitmap_any", sizeof("bitmap_any")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t start = atoi(s[2]);
			size_t cnt = atoi(s[3]);
			printf("%s\n", bitmap_any(bitmaps[idx].p, start, cnt) ? "true" : "false");
		}
		else if (strncmp(s[0], "bitmap_contains", sizeof("bitmap_contains")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t start = atoi(s[2]);
			size_t cnt = atoi(s[3]);
			bool value;
			if (strncmp(s[4], "true", sizeof("true")) == 0) {
				value = true;
			}
			else if (strncmp(s[4], "false", sizeof("false")) == 0) {
				value = false;
			}
			printf("%s\n", bitmap_contains(bitmaps[idx].p, start, cnt, value) ? "true" : "false");
		}
		else if (strncmp(s[0], "bitmap_count", sizeof("bitmap_count")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t start = atoi(s[2]);
			size_t cnt = atoi(s[3]);
			bool value;
			if (strncmp(s[4], "true", sizeof("true")) == 0) {
				value = true;
			}
			else if (strncmp(s[4], "false", sizeof("false")) == 0) {
				value = false;
			}
			printf("%zu\n", bitmap_count(bitmaps[idx].p, start, cnt, value));
		}
		else if (strncmp(s[0], "bitmap_dump", sizeof("bitmap_dump")) == 0) {
			size_t idx = atoi(&s[1][2]);
			bitmap_dump(bitmaps[idx].p);
		}
		else if (strncmp(s[0], "bitmap_expand", sizeof("bitmap_expand")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t ex_size = atoi(s[2]);
			bitmaps[idx].p = bitmap_expand(bitmaps[idx].p, ex_size);
		}
		else if (strncmp(s[0], "bitmap_set_all", sizeof("bitmap_set_all")) == 0) {
			size_t idx = atoi(&s[1][2]);
			bool value;
			if (strncmp(s[2], "true", sizeof("true")) == 0) {
				value = true;
			}
			else if (strncmp(s[2], "false", sizeof("false")) == 0) {
				value = false;
			}
			bitmap_set_all(bitmaps[idx].p, value);
		}
		else if (strncmp(s[0], "bitmap_flip", sizeof("bitmap_flip")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t bit_idx = atoi(s[2]);
			bitmap_flip(bitmaps[idx].p, bit_idx);
		}
		else if (strncmp(s[0], "bitmap_none", sizeof("bitmap_none")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t start = atoi(s[2]);
			size_t cnt = atoi(s[3]);
			printf("%s\n", bitmap_none(bitmaps[idx].p, start, cnt) ? "true" : "false");
		}
		else if (strncmp(s[0], "bitmap_reset", sizeof("bitmap_reset")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t bit_idx = atoi(s[2]);
			bitmap_reset(bitmaps[idx].p, bit_idx);
		}
		else if (strncmp(s[0], "bitmap_scan_and_flip", sizeof("bitmap_scan_and_flip")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t start = atoi(s[2]);
			size_t cnt = atoi(s[3]);
			bool value;
			if (strncmp(s[4], "true", sizeof("true")) == 0) {
				value = true;
			}
			else if (strncmp(s[4], "false", sizeof("false")) == 0) {
				value = false;
			}
			printf("%zu\n", bitmap_scan_and_flip(bitmaps[idx].p, start, cnt, value));
		}
		else if (strncmp(s[0], "bitmap_scan", sizeof("bitmap_scan")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t start = atoi(s[2]);
			size_t cnt = atoi(s[3]);
			bool value;
			if (strncmp(s[4], "true", sizeof("true")) == 0) {
				value = true;
			}
			else if (strncmp(s[4], "false", sizeof("false")) == 0) {
				value = false;
			}
			printf("%zu\n", bitmap_scan(bitmaps[idx].p, start, cnt, value));
		}
		else if (strncmp(s[0], "bitmap_set", sizeof("bitmap_set")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t bit_idx = atoi(s[2]);
			bool value;
			if (strncmp(s[3], "true", sizeof("true")) == 0) {
				value = true;
			}
			else if (strncmp(s[3], "false", sizeof("false")) == 0) {
				value = false;
			}
			bitmap_set(bitmaps[idx].p, bit_idx, value);
		}
		else if (strncmp(s[0], "bitmap_set_multiple", sizeof("bitmap_set_multiple")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t start = atoi(s[2]);
			size_t cnt = atoi(s[3]);
			bool value;
			if (strncmp(s[4], "true", sizeof("true")) == 0) {
				value = true;
			}
			else if (strncmp(s[4], "false", sizeof("false")) == 0) {
				value = false;
			}
			bitmap_set_multiple(bitmaps[idx].p, start, cnt, value);
		}
		else if (strncmp(s[0], "bitmap_size", sizeof("bitmap_size")) == 0) {
			size_t idx = atoi(&s[1][2]);
			printf("%zu\n",bitmap_size(bitmaps[idx].p));
		}
		else if (strncmp(s[0], "bitmap_test", sizeof("bitmap_test")) == 0) {
			size_t idx = atoi(&s[1][2]);
			size_t bit_idx = atoi(s[2]);
			bool value = bitmap_test(bitmaps[idx].p, bit_idx);
			printf("%s\n", value ? "true" : "false");
		}
		else if (strncmp(s[0], "delete", sizeof("delete")) == 0) {
			if (strncmp(s[1], "list", sizeof("list")-1) == 0) {
				size_t idx = atoi(&s[1][4]);
				while (!list_empty(&lists[idx])) {
					list_pop_front(&lists[idx]);
				}
			}
			else if (strncmp(s[1], "hash", sizeof("hash")-1) == 0) {
				size_t idx = atoi(&s[1][4]);
				hash_clear(&hashs[idx], NULL);
				hash_destroy(&hashs[idx], NULL);
			}
			else if (strncmp(s[1], "bm", sizeof("bm")-1) == 0) {
				size_t idx = atoi(&s[1][2]);
				bitmap_destroy(bitmaps[idx].p);
			}
		}
		else if (strncmp(s[0], "dumpdata", sizeof("dumpdata")) == 0) {
			if (strncmp(s[1], "list", sizeof("list")-1) == 0) {
				size_t idx = atoi(&s[1][4]);
				struct list_elem* elem;
				struct list_item* item;
				for (elem = list_begin(&lists[idx]); elem != list_end(&lists[idx]); elem = list_next(elem)) {
					item = list_entry(elem, struct list_item, elem);
					printf("%d ", item->data);
				}
				printf("\n");
			}
			else if (strncmp(s[1], "hash", sizeof("hash")-1) == 0) {
				size_t idx = atoi(&s[1][4]);
				struct hash_iterator i;
				hash_first(&i, &hashs[idx]);
				while (hash_next(&i))
				{
					struct hash_item* item = hash_entry(hash_cur(&i), struct hash_item, elem);
					printf("%d ", item->data);
				}
				printf("\n");
			}
			else if (strncmp(s[1], "bm", sizeof("bm")-1) == 0) {
				size_t idx = atoi(&s[1][2]);
				bitmap_dumpdata(bitmaps[idx].p);
			}
		}
		else{
			printf("wrong command\n");
		}
		for (i=0;i<7;i++) {
			strcpy(s[i], s[6]);
		}
	}
	return 0;
}
