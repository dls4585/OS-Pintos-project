#include "int_to_float.h"


int int_sub_float(int i, int f){
    return i*SHIFT - f;
}
int int_multi_float(int i, int f){
    return i*f;
}
int float_add_int(int i, int f){
    return i*SHIFT + f;
}
int float_multi_float(int f1, int f2){
    int64_t temp = f1;
    temp = (temp * f2) / SHIFT;
    return (int)temp;
}
int float_div_float(int f1, int f2){
    int64_t temp = f1;
    temp = temp*SHIFT / f2;
    return (int)temp;
}
int float_add_float(int f1, int f2){
    return f1+f2;
}
int float_sub_float(int f1, int f2){
    return f1-f2;
}
int float_div_int(int i, int f){
    return f / 2;
}