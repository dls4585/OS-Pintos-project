#include <stdio.h>
#include <stdint.h>
#define SHIFT (1<<14)
int int_sub_float(int, int);
int int_multi_float(int, int);
int float_add_int(int, int);
int float_multi_float(int, int);
int float_div_float(int, int);
int float_add_float(int, int);
int float_sub_float(int, int);
int float_div_int(int, int);